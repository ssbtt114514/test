
# V4 渲染兼容层

新增：

## VAO 状态缓存
维护：
- 当前绑定 VAO
- Array Buffer
- Element Buffer

目的：
减少重复状态切换。

## Shader 转译链
阶段：

GLSL 330
↓
兼容重写
↓
GLSL ES 300

后续：
- UBO 降级
- Geometry 替代
- Uniform 重映射
