/**
 * Created by: artDev
 * Copyright (c) 2025 artDev, SerpentSpirale, CADIndie.
 * For use under LGPL-3.0
 */

#ifndef POJAVLAUNCHER_EGL_H
#define POJAVLAUNCHER_EGL_H

#include <stdbool.h>
#include <EGL/egl.h>
#include "proc.h"
#include "unordered_map/unordered_map.h"

#define MAX_BOUND_BUFFERS 9
#define MAX_BOUND_BASEBUFFERS 4
#define MAX_DRAWBUFFERS 8
#define MAX_FBTARGETS 8
#define MAX_TMUS 8
#define MAX_TEXTARGETS 8

typedef struct {
    bool ready;
    GLuint indirectRenderBuffer;
} basevertex_renderer_t;

typedef struct {
    GLuint index;
    GLuint buffer;
    bool ranged;
    GLintptr  offset;
    GLintptr  size;
} basebuffer_binding_t;

typedef struct {
    GLuint color_targets[MAX_FBTARGETS];
    GLuint color_objects[MAX_FBTARGETS];
    GLuint color_levels[MAX_FBTARGETS];
    GLuint color_layers[MAX_FBTARGETS];
    GLenum virt_drawbuffers[MAX_DRAWBUFFERS];
    GLenum phys_drawbuffers[MAX_DRAWBUFFERS];
    GLsizei nbuffers;
} framebuffer_t;

typedef struct {
    bool ready;
    GLuint temp_texture;
    GLuint tempfb;
    GLuint destfb;
    void* depthData;
    GLsizei depthWidth, depthHeight;
} framebuffer_copier_t;

typedef struct {
    GLenum original_swizzle[4];  // 原始swizzle
    GLenum applied_swizzle[4];   // 已应用的swizzle（缓存）
    GLenum pending_swizzle[4];   // 待应用的swizzle（批量更新）
    GLboolean goofy_byte_order;
    GLboolean upload_bgra;
    GLboolean has_pending_update;  // 是否有待处理的更新
    GLenum texture_target;         // 纹理目标类型（GL_TEXTURE_2D, GL_TEXTURE_CUBE_MAP等）
} texture_swizzle_track_t;

typedef struct {
    GLint internalformat;
    GLenum type;
    GLenum format;
    bool valid;
} format_cache_entry_t;

#define FORMAT_CACHE_SIZE 64

// 前向声明内存池
typedef struct mempool mempool_t;

// 前向声明 shader 和 program 信息结构体（在 shader_wrapper.c 中定义）
typedef struct {
    GLenum shader_type;
    GLchar* source;
} shader_info_t;

typedef struct {
    GLuint frag_shader;
    GLchar* colorbindings[MAX_DRAWBUFFERS];
} program_info_t;

typedef struct {
    EGLContext phys_context;    //实际的EGL上下文句柄
    bool context_rdy;   //标记上下文是否已准备就绪
    bool es31, es32, buffer_storage, buffer_texture_ext, multidraw_indirect;    //支持OpenGL ES 3.1/3.2版本
    PFNGLDRAWELEMENTSBASEVERTEXPROC drawelementsbasevertex; //函数指针，指向绘制元素基顶点的函数
    GLint shader_version;   //着色器版本
    basevertex_renderer_t basevertex;   //基顶点渲染器
    GLuint multidraw_element_buffer;    //多重绘制元素缓冲区对象
    framebuffer_copier_t framebuffer_copier;    //帧缓冲复制器
    unordered_map* shader_map;  //着色器映射表
    unordered_map* program_map; //程序映射表
    unordered_map* framebuffer_map; //帧缓冲映射表
    unordered_map* texture_swztrack_map;    //纹理重组跟踪映射表
    unordered_map* bound_basebuffers[MAX_BOUND_BASEBUFFERS];    //绑定的基本缓冲区映射表数组
    int proxy_width, proxy_height, proxy_intformat, maxTextureSize; //代理纹理参数和最大纹理尺寸
    GLint max_drawbuffers;  //最大绘制缓冲区数
    GLuint bound_buffers[MAX_BOUND_BUFFERS];       //绑定的缓冲区对象数组
    GLuint program;     //当前使用的程序对象
    GLuint draw_framebuffer;    //绘制帧缓冲对象
    GLuint read_framebuffer;    //读取帧缓冲对象
    framebuffer_t* cached_draw_framebuffer;   //缓存的绘制帧缓冲对象
    framebuffer_t* cached_read_framebuffer;   //缓存的读取帧缓冲对象
    char* extensions_string;    //扩展字符串
    size_t extensions_capacity; //扩展字符串分配的容量
    size_t nextras;         //额外扩展数量
    int nextensions_es;     //ES扩展数量
    char** extra_extensions_array;      //额外扩展字符串数组
    format_cache_entry_t format_cache[FORMAT_CACHE_SIZE];   //纹理格式缓存
    int format_cache_index;    //格式缓存索引
    GLsizei multidraw_buffer_size;  //多重绘制缓冲区大小
    mempool_t* shader_info_pool;    //shader_info_t 内存池
    // Swizzle 批量更新相关
    GLuint pending_swizzle_textures[64];  // 待更新的纹理ID列表
    int pending_swizzle_count;            // 待更新数量
    bool swizzle_batch_mode;              // 是否处于批量更新模式
    // 热路径函数指针缓存（减少间接调用开销）
    struct {
        void (*glDrawArrays)(GLenum, GLint, GLsizei);
        void (*glDrawElements)(GLenum, GLsizei, GLenum, const void*);
        void (*glBindBuffer)(GLenum, GLuint);
        void (*glBindTexture)(GLenum, GLuint);
        void (*glTexParameteri)(GLenum, GLenum, GLint);
        void (*glGetTexParameteriv)(GLenum, GLenum, GLint*);
        void (*glGetIntegerv)(GLenum, GLint*);
        void (*glBufferData)(GLenum, GLsizeiptr, const void*, GLenum);
        void (*glBufferSubData)(GLenum, GLintptr, GLsizeiptr, const void*);
        void (*glCopyBufferSubData)(GLenum, GLenum, GLintptr, GLintptr, GLsizeiptr);
        void* (*glMapBufferRange)(GLenum, GLintptr, GLsizeiptr, GLbitfield);
        unsigned char (*glUnmapBuffer)(GLenum);
        void (*glFlushMappedBufferRange)(GLenum, GLintptr, GLsizeiptr);
    } fast_gl;
    // MultiDraw 环形缓冲区相关
    size_t multidraw_ring_head;  // 环形缓冲区头部位置
    size_t multidraw_ring_tail;  // 环形缓冲区尾部位置
    bool multidraw_ring_wrapped; // 是否已环绕
    mempool_t* program_info_pool;   //program_info_t 内存池
    mempool_t* framebuffer_pool;    //framebuffer_t 内存池
    mempool_t* swizzle_track_pool;  //texture_swizzle_track_t 内存池
} context_t;        //表示OpenGL ES的上下文状态信息

extern thread_local context_t *current_context;
extern void init_egl();
extern GLenum get_textarget_query_param(GLenum target);

#endif //POJAVLAUNCHER_EGL_H
