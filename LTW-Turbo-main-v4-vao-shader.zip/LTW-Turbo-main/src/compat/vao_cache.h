
#pragma once
#include <unordered_map>

/**
 * Vertex Array Object 状态缓存（实验版）
 * 目标：
 * - 减少重复 glBindVertexArray
 * - 为 GLES 后端提供状态复用
 */
struct VaoState {
    unsigned int arrayBuffer = 0;
    unsigned int elementBuffer = 0;
};

class VaoCache {
public:
    void bind(unsigned int id) { current = id; }
    VaoState& state(unsigned int id) { return cache[id]; }
    unsigned int currentId() const { return current; }

private:
    unsigned int current = 0;
    std::unordered_map<unsigned int, VaoState> cache;
};
