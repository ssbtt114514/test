
#pragma once
#include <string>

/**
 * Shader 转译链（实验版）
 * GLSL330 -> GLSL ES300
 */
inline std::string translateShader(std::string src) {
    auto replace=[&](const std::string& a,const std::string& b){
        size_t p=0;
        while((p=src.find(a,p))!=std::string::npos){
            src.replace(p,a.size(),b);
            p+=b.size();
        }
    };

    replace("#version 330 core","#version 300 es");
    replace("layout(location=","/*layout(location=");
    replace(" in "," attribute ");

    return src;
}
